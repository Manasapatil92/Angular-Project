export const environment = {
  production: true,
  name: 'production'
};
