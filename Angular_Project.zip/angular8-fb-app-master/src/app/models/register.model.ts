export class Register {
    firstName: string;
    lastName: string;
    dob: Date;
    email: string;
    password: string;
    gender: string;
    isActive: boolean;
}
