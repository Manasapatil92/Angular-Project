export class Post {
    id: string;
    post: string;
    userId: string;
    userPhotoId: string;
    postImageId: string;
    userName: string;
    isAdmin: boolean;
    profession: string;
    isActive: boolean;
}
